package edu.monmouth.cs.s1245759.lab5;

public class Course 
{
	private String courseCode;
	private String courseNumber;
	private String courseDescription;
	
	Course (String courseCode, String courseNumber, String courseDescription )
	{
		this.courseCode = courseCode;
		this.courseNumber = courseNumber;
		this.courseDescription = courseDescription;
	}
	
	public String toString()
	{
		return  "CourseCode: " + this.courseCode + "\n" +
				"CourseNumber: " + this.courseNumber + "\n" +
				"CourseDescription: " + this.courseDescription + "\n";
	}
}
