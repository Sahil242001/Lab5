package edu.monmouth.cs.s1245759.lab5;
import java.util.ArrayList;
public class StudentCourseTest 
{

	public static void main(String[] args) 
	{
		 StudentList cs176Students = new StudentList();
		 ArrayList<Course> courses = new ArrayList<Course>();
		 
		 Student s1 = new Student ("Ahmed, Saahil", "1219200", "s1219200@monmouth.edu", "CS", 2, "E.Cesario", 1.0, 2022, courses);

		 Student s2 = new Student ("Berardis, Anthony William", "1297598", "s1297598@monmouth.edu", "CS", 2, "R.Scherl", 1.0,2022, courses);
		 
		 Student s3 = new Student ("Clappsy, Thomas V", "1218375", "s1218375@monmouth.edu", "CS", 2, "J.Kretsch", 1.0, 2022, courses);
		 
		 
		 Course course1 = new Course ("CS", "CS175", "Description");
		 
		 Course course2 = new Course ("SE", "SE102", "Description");
		 
		 Course course3 = new Course ("MA", "MA130", "Description");
		 
		 Course course4 = new Course ("CS", "CS176", "Description");
		 
		 
		 cs176Students.addStudent(s1);
		 
		 cs176Students.addStudent(s2);
		 
		 cs176Students.addStudent(s3);
		 
		 
		 s1.addCourses(course1);
		 s1.addCourses(course4);
		 s1.addCourses(course2);
		 
		 
		 s2.addCourses(course1);
		 s2.addCourses(course2);
		 
		 
		 s3.addCourses(course3);
		 
		 
		 
		 cs176Students.listStudents();
		 
		 


	}

}
